مشروع تحويل تطبيق نُطق إلى Android باستخدام Capacitor

المحتويات:
- www/: ملفات تطبيق نُطق الأصلية كما وردت في ملف ZIP.
- package.json و capacitor.config.json: إعدادات مشروع Android.

متطلبات البناء:
1) كمبيوتر Windows أو macOS أو Linux.
2) Node.js LTS و Android Studio مع Android SDK.
3) اتصال إنترنت لأول تثبيت للحزم.

خطوات البناء:
1) فك ضغط nutq-android-project.zip.
2) افتح مجلد المشروع في Terminal / PowerShell.
3) نفّذ: npm install
4) نفّذ: npx cap add android
5) نفّذ: npx cap sync android
6) نفّذ: npx cap open android
7) في Android Studio انتظر اكتمال Gradle Sync.
8) للتجربة: Build > Build Bundle(s) / APK(s) > Build APK(s).
9) للنشر: Build > Generate Signed Bundle / APK > Android App Bundle.
   أنشئ مفتاح توقيع (keystore) واحفظه بمكان آمن ولا تشاركه.

ملاحظات مهمة قبل النشر:
- هذا مشروع مصدر جاهز لفتحه وبنائه في Android Studio، وليس APK/AAB مبنياً بعد.
- الوظائف المحلية في التطبيق تعتمد على localStorage. اختبر حفظ البيانات وإعادة فتح التطبيق على جهاز Android.
- تسجيل Google/Firebase الحالي يستخدم signInWithPopup/signInWithRedirect داخل صفحة ويب؛ قد لا يعمل كما هو في WebView الأصلي. يلزم تنفيذ واختبار تسجيل دخول Google أصلي (Capacitor Firebase Authentication) قبل الاعتماد على المزامنة السحابية.
- ملف firebase-config.js ما زال يحتوي قيماً تجريبية PLACEHOLDER. لا تفعّل المزامنة قبل إعداد مشروع Firebase وقواعد Firestore بشكل آمن.
- التطبيق يتعامل مع بيانات مرضى حساسة: لا تستخدم بيانات حقيقية في الاختبار، وجهّز سياسة خصوصية وموافقة/أساس قانوني مناسب، وراجع متطلبات Google Play الخاصة بالتطبيقات الصحية والبيانات قبل النشر.
- غيّر appId إلى معرّف فريد تملكه قبل أول نشر؛ لا تغيّره بعد نشر التطبيق.
